import jwt
import datetime
import os

# 🔐 Secure key (uses environment variable if available)
SECRET_KEY = os.getenv(
    "JWT_SECRET",
    "this_is_a_super_secure_secret_key_32_chars_long_12345"
)

# 🔐 Generate Token
def generate_token(payload):
    payload["exp"] = datetime.datetime.utcnow() + datetime.timedelta(hours=2)

    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    return token


# 🔐 Decode Token
def decode_token(token):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        return {"error": "Token expired"}
    except jwt.InvalidTokenError:
        return {"error": "Invalid token"}