import os

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "my_secure_random_key_987654321_secure")

    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
    DB_NAME = os.getenv("DB_NAME", "bot_detection_ecommerce")

    TOKEN_EXPIRY = int(os.getenv("TOKEN_EXPIRY", 3600))