from pymongo import MongoClient
from config.config import Config

try:
    client = MongoClient(Config.MONGO_URI)
    db = client[Config.DB_NAME]

    print("✅ Connected to MongoDB:", db.name)

except Exception as e:
    print("❌ MongoDB Connection Error:", e)

# Collections
users = db["users"]
products = db["products"]
orders = db["orders"]
bot_logs = db["bot_logs"]
cart = db["cart"]