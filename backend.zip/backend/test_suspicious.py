import requests
import time

url = "http://127.0.0.1:5000/"

for i in range(12):   # increase count
    requests.get(url)
    print(f"Request {i+1}")
    time.sleep(0.1)   # faster → triggers suspicious