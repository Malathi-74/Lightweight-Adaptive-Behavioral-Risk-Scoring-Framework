import joblib
import numpy as np

# 🔹 Load ML model
try:
    model = joblib.load("ml/bot_model.pkl")
except:
    model = None


# 🔹 Feature extraction
def extract_features(request_times):
    if len(request_times) < 5:
        return None

    intervals = np.diff(request_times)

    avg_time = np.mean(intervals)
    std_time = np.std(intervals)
    request_count = len(request_times)

    return avg_time, std_time, request_count


# 🔹 Main prediction function
def predict_bot_from_times(request_times):
    features = extract_features(request_times)

    if features is None:
        return False

    avg_time, std_time, request_count = features

    # 🔥 RULE-BASED DETECTION (FAST & RELIABLE)

    # Very fast requests → BOT
    if avg_time < 0.2:
        return True

    # Too many requests → BOT
    if request_count > 30:
        return True

    # 🔹 ML MODEL (if available)
    if model:
        try:
            features_array = np.array([features])
            prediction = model.predict(features_array)
            return prediction[0] == 1
        except:
            return False

    # Default → HUMAN
    return False