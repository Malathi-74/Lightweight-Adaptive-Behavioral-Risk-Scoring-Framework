from database.db import products

def get_products():
    return list(products.find({}, {"_id": 0}))