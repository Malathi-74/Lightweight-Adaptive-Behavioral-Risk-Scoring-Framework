import random
import time
import re
from datetime import datetime

from flask import request
from database.db import users, bot_logs
from utils.password_helper import hash_password, check_password
from utils.jwt_helper import generate_token

# 🔥 IMPORTANT IMPORTS (FIXED)
from middleware.bot_detector import request_log, detect_bot
from services.bot_service import bot_ips

# 🔐 OTP STORAGE
otp_store = {}
otp_attempts = {}

# 🔥 CONFIG
BLOCK_TIME = 60
OTP_EXPIRY = 120
MAX_OTP_ATTEMPTS = 3
TIME_WINDOW = 10   # seconds


# 🔐 OTP GENERATOR
def generate_otp():
    return str(random.randint(100000, 999999))


# 🔹 REGISTER
def register_user(data):
    email = data.get("email", "").strip()
    password = data.get("password", "").strip()
    name = data.get("name", "").strip()

    if not email or not password or not name:
        return {"error": "All fields required"}

    if not re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", email):
        return {"error": "Invalid email"}

    if users.find_one({"email": email}):
        return {"error": "User exists"}

    users.insert_one({
        "name": name,
        "email": email,
        "password": hash_password(password),
        "role": "user"
    })

    return {"message": "Registered successfully"}


# 🔹 LOGIN (FINAL STABLE)
def login_user(data):
    email = data.get("email", "").strip()
    password = data.get("password", "").strip()

    if not email or not password:
        return {"error": "Email & password required"}

    user = users.find_one({"email": email})

    if not user:
        return {"error": "User not found"}

    if not check_password(password, user["password"]):
        return {"error": "Invalid password"}

    ip = request.remote_addr
    now = time.time()

    # 🔥 IMPORTANT: UPDATE REQUEST LOG
    detect_bot()

    # 🔥 BEHAVIOR DATA
    typing_pattern = data.get("typing_pattern", [])
    mouse_moves = data.get("mouse_moves", 0)

    avg_typing = sum(typing_pattern)/len(typing_pattern) if typing_pattern else 0

    print("\n====== LOGIN DEBUG ======")
    print("IP:", ip)
    print("Typing:", avg_typing)
    print("Mouse:", mouse_moves)
    print("=========================\n")

    # 🔴 HARD BOT (NO HUMAN ACTIVITY)
    if avg_typing == 0 and mouse_moves == 0:
        print("🤖 BOT (no behavior)")

        bot_ips[ip] = now

        bot_logs.insert_one({
            "ip": ip,
            "status": "BOT",
            "typing_speed": avg_typing,
            "mouse_moves": mouse_moves,
            "time": datetime.now().strftime("%H:%M:%S")
        })

        return {"error": "Bot detected 🚫"}

    # 🔴 BLOCK IF ALREADY BOT
    if ip in bot_ips and now - bot_ips[ip] < BLOCK_TIME:
        return {"error": "Blocked (bot) 🚫"}

    # 🔥 REQUEST-BASED DETECTION
    if ip in request_log:

        recent = [t for t in request_log[ip] if now - t < TIME_WINDOW]
        count = len(recent)

        print("⚡ Requests:", count)

        # 🟡 SUSPICIOUS → OTP
        if count >= 8 and count < 15:

            otp = generate_otp()

            otp_store[email] = {
                "otp": otp,
                "time": now
            }

            otp_attempts[email] = 0

            print("🔐 OTP:", otp)

            bot_logs.insert_one({
                "ip": ip,
                "status": "SUSPICIOUS",
                "typing_speed": avg_typing,
                "mouse_moves": mouse_moves,
                "time": datetime.now().strftime("%H:%M:%S")
            })

            return {
                "otp_required": True,
                "message": "Suspicious activity - OTP required"
            }

        # 🔴 BOT
        if count >= 15:
            bot_ips[ip] = now

            bot_logs.insert_one({
                "ip": ip,
                "status": "BOT",
                "typing_speed": avg_typing,
                "mouse_moves": mouse_moves,
                "time": datetime.now().strftime("%H:%M:%S")
            })

            return {"error": "Bot detected 🚫"}

    # 🟢 HUMAN
    print("✅ HUMAN LOGIN")

    bot_logs.insert_one({
        "ip": ip,
        "status": "HUMAN",
        "typing_speed": avg_typing,
        "mouse_moves": mouse_moves,
        "time": datetime.now().strftime("%H:%M:%S")
    })

    token = generate_token({
        "email": email,
        "role": user.get("role", "user")
    })

    return {
        "token": token,
        "message": "Login successful"
    }


# 🔐 VERIFY OTP
def verify_otp(data):
    email = data.get("email")
    otp = data.get("otp")

    if email not in otp_store:
        return {"error": "No OTP found"}

    stored = otp_store[email]

    # ⏱ EXPIRY
    if time.time() - stored["time"] > OTP_EXPIRY:
        otp_store.pop(email, None)
        return {"error": "OTP expired"}

    # ❌ WRONG OTP
    if stored["otp"] != otp:

        otp_attempts[email] = otp_attempts.get(email, 0) + 1

        if otp_attempts[email] >= MAX_OTP_ATTEMPTS:
            otp_store.pop(email, None)
            otp_attempts.pop(email, None)
            return {"error": "Too many wrong attempts"}

        return {"error": "Invalid OTP"}

    # ✅ SUCCESS
    otp_store.pop(email, None)
    otp_attempts.pop(email, None)

    user = users.find_one({"email": email})

    token = generate_token({
        "email": email,
        "role": user.get("role", "user")
    })

    print("✅ OTP VERIFIED")

    return {
        "token": token,
        "message": "OTP verified"
    }