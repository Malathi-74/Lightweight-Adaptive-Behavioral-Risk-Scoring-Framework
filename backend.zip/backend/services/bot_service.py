from database.db import bot_logs
from datetime import datetime
import time

# 🔥 TRACKING
bot_ips = {}
suspicious_ips = {}
request_log = {}

BLOCK_TIME = 60
MAX_REQUESTS = 10
TIME_WINDOW = 10


# 🔥 CLEAN OLD IPS
def clean_old_ips():
    now = time.time()

    # 🔴 BOT CLEAN
    for ip in list(bot_ips.keys()):
        if now - bot_ips[ip] > BLOCK_TIME:
            del bot_ips[ip]

    # 🟡 SUSPICIOUS CLEAN
    for ip in list(suspicious_ips.keys()):
        if now - suspicious_ips[ip] > BLOCK_TIME:
            del suspicious_ips[ip]


# 🔥 DETECT BOT (FIXED)
def detect_bot(ip):
    now = time.time()

    clean_old_ips()

    if ip not in request_log:
        request_log[ip] = []

    # remove old requests
    request_log[ip] = [t for t in request_log[ip] if now - t < TIME_WINDOW]

    request_log[ip].append(now)

    request_count = len(request_log[ip])

    print("🔥 detect_bot CALLED")
    print(f"IP: {ip} | Requests: {request_count}")

    # 🔴 BOT (HIGH LEVEL)
    if request_count > 25:
        bot_ips[ip] = now

        print("🚫 BOT DETECTED:", ip)

        bot_logs.insert_one({
            "ip": ip,
            "status": "BOT",
            "time": datetime.now().strftime("%H:%M:%S")
        })

        return "bot"   # ✅ IMPORTANT

    # 🟡 SUSPICIOUS
    if request_count >= MAX_REQUESTS:
        suspicious_ips[ip] = now

        print("⚠️ SUSPICIOUS DETECTED:", ip)

        bot_logs.insert_one({
            "ip": ip,
            "status": "SUSPICIOUS",
            "time": datetime.now().strftime("%H:%M:%S")
        })

        return "suspicious"   # ✅ IMPORTANT

    print("SUSPICIOUS IPS:", suspicious_ips)

    # 🟢 NORMAL
    return "normal"   # ✅ IMPORTANT


# 🔥 OPTIONAL BOT LOG (keep as is)
def log_bot(ip):
    now = time.time()

    bot_ips[ip] = now

    bot_logs.insert_one({
        "ip": ip,
        "status": "BOT",
        "time": datetime.now().strftime("%H:%M:%S")
    })