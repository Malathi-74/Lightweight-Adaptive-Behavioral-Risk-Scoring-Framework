from database.db import orders

def create_order(user_id, data):
    order = {
        "user_id": user_id,
        "products": data["products"],
        "total": data["total"]
    }

    orders.insert_one(order)

    return {"message": "Order placed successfully"}