import requests

url = "http://127.0.0.1:5000/"

for i in range(30):   # higher than bot threshold
    requests.get(url)
    print(f"Request {i+1}")