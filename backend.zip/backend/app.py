import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, render_template, jsonify
from flask_cors import CORS

from database.db import bot_logs
from middleware.bot_detector import detect_bot
from utils.jwt_helper import decode_token

from controllers.auth_controller import auth_bp
from controllers.product_controller import product_bp
from controllers.order_controller import order_bp
from controllers.bot_controller import bot_bp


def create_app():
    app = Flask(__name__)
    CORS(app)

    # --------------------------------------------------
    # 🔥 BOT DETECTION (SAFE VERSION)
    # --------------------------------------------------
    @app.before_request
    def track_requests():

        # Skip static + dashboard + frontend pages
        if (
            request.path.startswith("/static") or
            request.path.startswith("/dashboard") or
            request.path.startswith("/dashboard-data") or
            request.path.startswith("/products") or
            request.path.startswith("/cart") or
            request.path.startswith("/order-success")
        ):
            return

        detect_bot()

    # --------------------------------------------------
    # 🔹 API ROUTES
    # --------------------------------------------------
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(product_bp, url_prefix="/api/products")
    app.register_blueprint(order_bp, url_prefix="/api/orders")
    app.register_blueprint(bot_bp, url_prefix="/api/bots")

    # --------------------------------------------------
    # 🔹 NORMAL PAGES
    # --------------------------------------------------
    @app.route("/")
    def home():
        return render_template("verify.html")

    @app.route("/login")
    def login_page():
        return render_template("login.html")

    @app.route("/register")
    def register_page():
        return render_template("register.html")

    @app.route("/products")
    def products_page():
        return render_template("products.html")

    @app.route("/cart")
    def cart_page():
        return render_template("cart.html")

    @app.route("/order-success")
    def order_success():
        return render_template("order_success.html")

    @app.route("/blocked")
    def blocked():
        return render_template("blocked.html")

    # --------------------------------------------------
    # 🔐 TOKEN HELPER
    # --------------------------------------------------
    def get_clean_token():
        token = request.args.get("token") or request.headers.get("Authorization")

        if not token:
            return None

        if token.startswith("Bearer "):
            token = token.split(" ")[1]

        return token

    # --------------------------------------------------
    # 🔒 ADMIN DASHBOARD
    # --------------------------------------------------
    @app.route("/dashboard")
    def dashboard():

        token = get_clean_token()

        if not token:
            return "Token missing ❌", 401

        try:
            data = decode_token(token)

            if data.get("role") != "admin":
                return "Access Denied ❌", 403

            return render_template("dashboard.html")

        except Exception as e:
            print("DASHBOARD ERROR:", e)
            return "Invalid token ❌", 401

    # --------------------------------------------------
    # 🔒 DASHBOARD DATA
    # --------------------------------------------------
    @app.route("/dashboard-data")
    def dashboard_data():

        token = get_clean_token()

        if not token:
            return jsonify({"error": "Unauthorized"}), 401

        try:
            data = decode_token(token)

            if data.get("role") != "admin":
                return jsonify({"error": "Forbidden"}), 403

        except Exception as e:
            print("DATA ERROR:", e)
            return jsonify({"error": "Invalid token"}), 401

        try:
            logs = list(bot_logs.find().sort("_id", -1).limit(20))

            result = []

            for log in logs:
                result.append({
                    "ip": log.get("ip", "N/A"),
                    "status": log.get("status", "HUMAN"),
                    "typing": log.get("typing_speed", 0),
                    "mouse": log.get("mouse_moves", 0),
                    "score": log.get("score", 0),
                    "time": log.get("time", "N/A")
                })

            return jsonify(result)

        except Exception as e:
            print("DASHBOARD DATA ERROR:", e)
            return jsonify([])

    return app


# --------------------------------------------------
# 🚀 RUN APP
# --------------------------------------------------
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, use_reloader=False)  # ✅ ENABLE DEBUG FOR DEVELOPMENT