from utils.password_helper import hash_password

print(hash_password("1234"))