PROJECT SETUP GUIDE (STEP BY STEP)

---

🔹 STEP 1 — INSTALL REQUIRED SOFTWARE

1. Install Python (3.10 or higher)
   👉 https://www.python.org/downloads/

   ✔ During installation, ENABLE:
   ✔ "Add Python to PATH"

2. Install MongoDB Community Server
   👉 https://www.mongodb.com/try/download/community

   ✔ Install with default settings
   ✔ Make sure MongoDB service is running

---

🔹 STEP 2 — OPEN THE PROJECT

1. Extract the ZIP file
2. Open the project folder
3. Go inside:

   backend/

---

🔹 STEP 3 — INSTALL DEPENDENCIES

Open terminal / command prompt inside backend folder:

👉 Run:

pip install -r requirements.txt

✔ This installs all required libraries

---

🔹 STEP 4 — START THE APPLICATION

👉 Run:

python app.py

✔ You should see:
"Running on http://127.0.0.1:5000"

---

🔹 STEP 5 — SETUP DATABASE (VERY IMPORTANT)

Open a new terminal:

👉 Run:

mongosh

👉 Then run:

use bot_detection_ecommerce

👉 Insert sample products:

db.products.insertMany([
{ name: "Red Dress", price: 1500 },
{ name: "Blue Jeans", price: 2000 },
{ name: "Black T-Shirt", price: 800 },
{ name: "Shoes", price: 3000 }
])

✔ Now database is ready

---

🔹 STEP 6 — OPEN APPLICATION

Open browser:

http://127.0.0.1:5000

---

🔹 STEP 7 — USE THE APPLICATION

1. Register a new account
2. Login
3. View products
4. Add to cart
5. Place order
6. (Admin can access dashboard)

---

🔹 IMPORTANT NOTES

✔ MongoDB must be running before starting app
✔ Do NOT skip product insertion step
✔ If error occurs → restart server and try again

---

🏆 DONE — APPLICATION IS READY TO USE
