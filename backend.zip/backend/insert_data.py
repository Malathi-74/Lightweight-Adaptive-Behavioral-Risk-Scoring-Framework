from database.db import products

products.insert_many([
    {"name": "Shirt", "price": 500},
    {"name": "Shoes", "price": 1200},
    {"name": "Watch", "price": 2000}
])

print("✅ Data inserted successfully")