from flask import Blueprint, jsonify
from database.db import products

# Create blueprint
product_bp = Blueprint("products", __name__)

# --------------------------------------------------
# ✅ GET ALL PRODUCTS FROM MONGODB
# --------------------------------------------------
@product_bp.route("/", methods=["GET"])
def get_products():
    try:
        # Fetch all products and remove Mongo _id
        data = list(products.find({}, {"_id": 0}))

        return jsonify(data)

    except Exception as e:
        print("PRODUCT FETCH ERROR:", e)
        return jsonify({"error": "Failed to load products"}), 500