from flask import Blueprint, request, jsonify
from database.db import cart, products

cart_bp = Blueprint("cart", __name__)

# ADD TO CART
@cart_bp.route("/add", methods=["POST"])
def add_to_cart():
    data = request.json

    product_name = data.get("product")

    product = products.find_one({"name": product_name})

    if not product:
        return jsonify({"error": "Product not found"}), 404

    cart.insert_one({
        "product": product_name,
        "price": product["price"]
    })

    return jsonify({"message": "Added to cart"})


# GET CART
@cart_bp.route("/", methods=["GET"])
def get_cart():
    items = list(cart.find({}, {"_id": 0}))
    return jsonify(items)