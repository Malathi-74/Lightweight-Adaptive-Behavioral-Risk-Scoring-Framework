from flask import Blueprint, jsonify, request
from database.db import bot_logs
from utils.jwt_helper import decode_token

bot_bp = Blueprint("bots", __name__)

@bot_bp.route("/logs")
def get_logs():
    token = request.headers.get("Authorization")

    if not token:
        return {"error": "Unauthorized"}, 401

    try:
        data = decode_token(token)

        if data.get("role") != "admin":
            return {"error": "Access denied"}, 403

    except:
        return {"error": "Invalid token"}, 401

    return jsonify(list(bot_logs.find({}, {"_id": 0})))