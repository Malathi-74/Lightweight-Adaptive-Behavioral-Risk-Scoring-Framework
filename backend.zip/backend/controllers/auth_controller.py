from flask import Blueprint, request, jsonify, redirect
from services.auth_service import register_user, login_user, otp_store
from utils.jwt_helper import generate_token
from database.db import users

from services.bot_service import detect_bot, suspicious_ips, bot_ips

import random
import time

auth_bp = Blueprint("auth", __name__)


# 🔹 REGISTER
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.json
    result = register_user(data)

    if "error" in result:
        return jsonify(result), 400

    return jsonify(result)


# 🔹 LOGIN
@auth_bp.route("/login", methods=["POST"])
def login():

    ip = request.remote_addr
    status = detect_bot(ip)

    print("\n====== LOGIN DEBUG ======")
    print("IP:", ip)
    print("STATUS:", status)
    print("BOT IPS:", bot_ips)
    print("SUSPICIOUS IPS:", suspicious_ips)
    print("=========================\n")

    data = request.json
    email = data.get("email")

    # 🔴 BLOCK BOT
    if ip in bot_ips or status == "bot":
        print("🚫 BOT DETECTED → BLOCKED")
        return jsonify({"error": "Blocked: Bot detected"}), 403

    # 🟡 FORCE OTP FOR SUSPICIOUS
    if ip in suspicious_ips or status == "suspicious":
        print("⚠️ SUSPICIOUS → OTP REQUIRED")

        otp = str(random.randint(100000, 999999))

        otp_store[email] = {
            "otp": otp,
            "time": time.time()
        }

        print(f"📩 OTP for {email}: {otp}")

        return jsonify({
            "message": "Suspicious activity detected",
            "otp_required": True
        })

    # ✅ NORMAL LOGIN
    result = login_user(data)

    if "error" in result:
        return jsonify(result), 401

    if result.get("otp_required"):
        return jsonify(result)

    return jsonify(result)


# 🔐 VERIFY OTP
@auth_bp.route("/verify-otp", methods=["POST"])
def verify_otp():
    data = request.json
    email = data.get("email")
    otp = data.get("otp")

    if email not in otp_store:
        return jsonify({"error": "No OTP found"}), 400

    stored = otp_store[email]["otp"]

    if stored != otp:
        return jsonify({"error": "Invalid OTP"}), 401

    user = users.find_one({"email": email})

    token = generate_token({
        "email": email,
        "role": user.get("role", "user")
    })

    # 🧹 REMOVE OTP AFTER SUCCESS
    otp_store.pop(email, None)

    return jsonify({
        "token": token,
        "message": "Login successful"
    })