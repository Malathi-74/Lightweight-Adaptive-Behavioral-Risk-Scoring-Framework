from flask import Blueprint, jsonify, request
from database.db import cart, orders
from utils.jwt_helper import decode_token
from datetime import datetime
import uuid

order_bp = Blueprint("orders", __name__)

# --------------------------------------------------
# 🟢 CREATE ORDER
# --------------------------------------------------
@order_bp.route("/create", methods=["POST"])
def create_order():

    token = request.headers.get("Authorization")

    if not token:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        data = decode_token(token)
        email = data.get("email")

        if data.get("role") not in ["user", "admin"]:
            return jsonify({"error": "Invalid user"}), 403

    except Exception as e:
        print("TOKEN ERROR:", e)
        return jsonify({"error": "Invalid token"}), 401

    # 🔥 GET ITEMS FROM FRONTEND
    body = request.get_json() or {}
    items = body.get("items", [])

    if not items:
        return jsonify({"error": "Cart is empty"}), 400

    # 🔥 CALCULATE TOTAL (WITH QTY)
    total = sum(item.get("price", 0) * item.get("qty", 1) for item in items)

    # 🔥 GENERATE ORDER ID
    order_id = str(uuid.uuid4())[:8].upper()

    # 🔥 DATE
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 🔥 SAVE ORDER
    order_data = {
        "order_id": order_id,
        "email": email,
        "items": items,
        "total": total,
        "created_at": created_at
    }

    orders.insert_one(order_data)

    # 🔥 CLEAR USER CART (DB CART, optional)
    cart.delete_many({"email": email})

    return jsonify({
        "message": "Order placed successfully",
        "order_id": order_id,
        "total": total,
        "date": created_at
    })


# --------------------------------------------------
# 🟢 GET USER ORDERS
# --------------------------------------------------
@order_bp.route("/my-orders", methods=["GET"])
def get_my_orders():

    token = request.headers.get("Authorization")

    if not token:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        data = decode_token(token)
        email = data.get("email")

    except Exception as e:
        print("TOKEN ERROR:", e)
        return jsonify({"error": "Invalid token"}), 401

    user_orders = list(orders.find({"email": email}, {"_id": 0}))

    return jsonify(user_orders)


# --------------------------------------------------
# 🟢 GET ALL ORDERS (ADMIN ONLY)
# --------------------------------------------------
@order_bp.route("/all", methods=["GET"])
def get_all_orders():

    token = request.headers.get("Authorization")

    if not token:
        return jsonify({"error": "Unauthorized"}), 401

    try:
        data = decode_token(token)

        if data.get("role") != "admin":
            return jsonify({"error": "Forbidden"}), 403

    except Exception as e:
        print("TOKEN ERROR:", e)
        return jsonify({"error": "Invalid token"}), 401

    all_orders = list(orders.find({}, {"_id": 0}))

    return jsonify(all_orders)