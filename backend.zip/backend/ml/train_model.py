import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier

# Sample dataset
X = [
    [1.2, 0.5, 10],
    [1.0, 0.4, 12],
    [0.8, 0.3, 15],
    [0.1, 0.01, 50],
    [0.2, 0.02, 60],
    [0.05, 0.01, 80]
]

y = [0, 0, 0, 1, 1, 1]

model = RandomForestClassifier()
model.fit(X, y)

# Save model
joblib.dump(model, "ml/bot_model.pkl")

print("Model created successfully!")