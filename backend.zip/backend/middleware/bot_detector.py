from flask import request
from time import time

# 🔥 GLOBAL REQUEST STORAGE
request_log = {}

# 🔥 SETTINGS (BALANCED)
TIME_WINDOW = 10   # seconds


def detect_bot():
    ip = request.remote_addr
    now = time()

    # Initialize
    if ip not in request_log:
        request_log[ip] = []

    # 🔥 Add request (NO skipping)
    request_log[ip].append(now)

    # 🔥 Keep only recent requests
    request_log[ip] = [t for t in request_log[ip] if now - t < TIME_WINDOW]

    request_count = len(request_log[ip])

    print(f"🔥 detect_bot | IP: {ip} | Count: {request_count}")

    # ❗ Not enough data → HUMAN
    if request_count < 5:
        return "HUMAN"

    # Time difference
    time_diff = request_log[ip][-1] - request_log[ip][0]

    print(f"⏱ Time diff: {time_diff:.2f}s")

    # 🔴 BOT (very fast spam)
    if request_count >= 12 and time_diff < 3:
        print("🚫 BOT DETECTED")
        return "BOT"

    # 🟡 SUSPICIOUS (medium speed)
    if request_count >= 6 and time_diff < 6:
        print("⚠️ SUSPICIOUS DETECTED")
        return "SUSPICIOUS"

    # 🟢 HUMAN
    return "HUMAN"