from flask import request, jsonify
from utils.jwt_helper import decode_token


def admin_required(func):
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization")

        if not auth_header:
            return jsonify({"error": "Token missing"}), 401

        token = auth_header.split(" ")[1]
        data = decode_token(token)

        if not data:
            return jsonify({"error": "Invalid token"}), 401

        if data.get("role") != "admin":
            return jsonify({"error": "Admin only access"}), 403

        return func(*args, **kwargs)

    wrapper.__name__ = func.__name__
    return wrapper